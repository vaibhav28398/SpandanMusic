<?php
echo mime_content_type("songs/Katy Perry - Roar.mp3");
?>