<?php

$con = mysqli_connect("localhost", "root", "", "spandan_music") or die("Connection was not established");


?>