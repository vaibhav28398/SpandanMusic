
        <script src="include/jquery-2.1.4.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/Dependencies/bootstrap337.min.css">
        <link rel="stylesheet" type="text/css" href="css/Dependencies/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap-social.css">
        <link rel="stylesheet" type="text/css" href="css/Dependencies/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/Dependencies/w3-theme.css">
        <link rel="stylesheet" type="text/css" href="css/Dependencies/w3.css">
        
        <script src="js/bootstrap.min.js"></script>
        <link href="google-font-apna.css" type="text/css" rel="stylesheet">


        <link rel="stylesheet" type="text/css" href="include/lv-ripple.css">
        <link rel="stylesheet" type="text/css" href="include/style.css">
        <link rel="stylesheet" type="text/css" href="main.css" >

<link href="css/Dependencies/bootstrap(3.3.0).min.css" type="text/css" rel="stylesheet" id="bootstrap-css">
<script src="js/bootstrap(3.3.0).min.js"></script>
<script src="js/jquery(1.11.1).min.js"></script>
<script src="fb.js"></script>