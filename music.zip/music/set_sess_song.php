<?php

	session_start();
	$_SESSION['omega']=$_POST['arguments'][0];

?>